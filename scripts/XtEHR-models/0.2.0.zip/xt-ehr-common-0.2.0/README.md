# Xt-EHR FHIR Implementation Guide
<br> </br>
### Publication
This ImplementationGuide is published in the following locations:

Continuous Build: __http://build.fhir.org/ig/Xt-EHR/xt-ehr-common__
Canonical / permanent URL: 
<br/>

### Issues
Issues and change requests are managed here:  

Issues:  __https://github.com/Xt-EHR/xt-ehr-common/issues)__  


---

