Reported findings and relevant discussions are documented as [GitHub issues](https://github.com/Xt-EHR/xt-ehr-common/issues).  
