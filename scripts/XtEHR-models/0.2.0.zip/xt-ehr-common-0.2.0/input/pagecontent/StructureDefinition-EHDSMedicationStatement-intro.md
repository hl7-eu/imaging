<div class="stakeholder-note">

Feedback is welcome on any aspect of the content.<br>However, the following topics have been identified as areas where input would be particularly valuable:<br>  


<li><strong>intendedUseType.<strong> Is the element used as a category of purpose of use, or simply to signal whether a medication is used for therapeutic, diagnosis, prophylaxis, etc.  

</div>